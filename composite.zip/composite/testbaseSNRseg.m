%  % % % %--------------------------------------emd_OMLSA_IMCRA-------------------------------------% % % %

%%

 addpath(genpath('D:\partie programation\composite'));

addpath(genpath('D:\resultatsmohamed27072020'));

cfiles=dir(fullfile('D:\resultatsmohamed27072020','data_clean_testset_wav_16k\*.wav'));

  nfiles=dir(fullfile('D:\resultatsmohamed27072020','cleaned_testset_wav_16k_48600\*.wav'));

%   nfiles=dir(fullfile('D:\matlab_dnn_denoising','noisy\DRBABBLE\10db\*.wav'));
 
 
   for i=1:length(nfiles)
    
    
 [clean,Srate,nbits]= wavread(cfiles(i).name);  % parole propre
    
 [x,Srate,nbits]= wavread(nfiles(i).name);	% parole bruit�e



% --------------------------------------------------------------------------
% -------------------------------- E N D --------------------------------------


 
[cLLR(i) cSNRseg(i) cWSS(i) cPESQ(i)]= mcomposite(cfiles(i).name,nfiles(i).name) ;
 
   
 [Csig(i) Cbak(i) Covl(i)]= composite(cfiles(i).name,nfiles(i).name) ; 
   end
   
   
   
  cSNRseg = mean(cSNR),cPESQ = mean(cPESQ)
   
Csig= mean(Csig),Cbak= mean(Cbak), Covl= mean(Covl)


 
%  cLLR = mean(cLLR), cWSS = mean(cWSS),
 

